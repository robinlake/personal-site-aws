import React from 'react';
import { Name } from './name';
 
export class Title extends React.Component{
  
    render(){
        return (
            <div id="title">
                <Name />
            </div>
        );
    };
 
}