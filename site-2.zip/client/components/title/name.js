import React from 'react';
 
export class Name extends React.Component{
  
    render(){
        return (
            <div id="nameBox">
                <p id="name">Robin Lake</p>
                <p id="slogan">Web Development</p>
            </div>
        );
    };
 
}